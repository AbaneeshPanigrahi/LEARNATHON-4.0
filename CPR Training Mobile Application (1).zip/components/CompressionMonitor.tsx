import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Hand, Smartphone, Zap, Target } from 'lucide-react';

interface CompressionMonitorProps {
  isActive: boolean;
  onCompression: (depth: number) => void;
  targetDepth: [number, number];
}

export function CompressionMonitor({ isActive, onCompression, targetDepth }: CompressionMonitorProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [currentDepth, setCurrentDepth] = useState(0);
  const [pressureIntensity, setPressureIntensity] = useState(0);
  const compressionAreaRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();

  const maxDepth = Math.max(...targetDepth) + 2;

  const simulateCompression = useCallback((force: number) => {
    const depth = Math.min(force * maxDepth, maxDepth);
    setCurrentDepth(depth);
    setPressureIntensity(Math.min(force * 100, 100));

    if (depth > 1 && isActive) {
      onCompression(depth);
      
      if (compressionAreaRef.current) {
        compressionAreaRef.current.style.transform = `scale(${0.95 + (depth / maxDepth) * 0.1})`;
      }
    }
  }, [maxDepth, isActive, onCompression]);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (!isActive) return;
    
    e.preventDefault();
    setIsPressed(true);
    
    const touch = e.touches[0];
    if (touch) {
      const force = (touch as any).force || 0.5;
      simulateCompression(force);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isActive || !isPressed) return;
    
    e.preventDefault();
    const touch = e.touches[0];
    if (touch) {
      const force = (touch as any).force || 0.5;
      simulateCompression(force);
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    setIsPressed(false);
    setCurrentDepth(0);
    setPressureIntensity(0);
    
    if (compressionAreaRef.current) {
      compressionAreaRef.current.style.transform = 'scale(1)';
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isActive) return;
    
    setIsPressed(true);
    simulateCompression(0.7);
  };

  const handleMouseUp = () => {
    setIsPressed(false);
    setCurrentDepth(0);
    setPressureIntensity(0);
    
    if (compressionAreaRef.current) {
      compressionAreaRef.current.style.transform = 'scale(1)';
    }
  };

  const handleMouseLeave = handleMouseUp;

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const depthPercentage = (currentDepth / maxDepth) * 100;
  const isInTargetRange = currentDepth >= targetDepth[0] && currentDepth <= targetDepth[1];

  return (
    <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg">
            <Smartphone className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-white">Compression Monitor</h3>
        </div>
        {isPressed && (
          <Badge className="bg-gradient-to-r from-green-500 to-emerald-400 text-white border-0 animate-pulse">
            <Zap className="w-3 h-3 mr-1" />
            Detecting
          </Badge>
        )}
      </div>

      {/* Current Depth Display */}
      <div className="text-center mb-6">
        <div className="mb-2">
          <span className="text-purple-300 text-sm">Target Depth: </span>
          <span className="text-white font-medium">{targetDepth[0]}-{targetDepth[1]} cm</span>
        </div>
        <div className="text-4xl font-bold mb-2">
          <span className={`transition-colors duration-300 ${
            isInTargetRange ? 'text-green-400' : 'text-white'
          }`}>
            {currentDepth.toFixed(1)} cm
          </span>
        </div>
        {isInTargetRange && currentDepth > 0 && (
          <div className="text-green-400 text-sm flex items-center justify-center gap-1">
            <Target className="w-4 h-4" />
            Perfect Range!
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <div className="space-y-3 mb-6">
        <div className="flex justify-between text-sm">
          <span className="text-purple-200">Compression Depth</span>
          <span className="text-white font-medium">{depthPercentage.toFixed(0)}%</span>
        </div>
        
        <div className="relative">
          <div className="h-4 bg-white/10 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 ${
                isInTargetRange 
                  ? 'bg-gradient-to-r from-green-500 to-emerald-400' 
                  : 'bg-gradient-to-r from-purple-500 to-pink-400'
              }`}
              style={{ width: `${depthPercentage}%` }}
            ></div>
          </div>
          
          {/* Target range indicators */}
          <div className="flex justify-between text-xs text-purple-300 mt-1">
            <span>0cm</span>
            <span className="text-green-400">{targetDepth[0]}cm</span>
            <span className="text-green-400">{targetDepth[1]}cm</span>
            <span>{maxDepth}cm</span>
          </div>
        </div>
      </div>

      {/* Interactive Compression Area */}
      <div
        ref={compressionAreaRef}
        className={`
          relative h-48 rounded-2xl border-2 transition-all duration-200 cursor-pointer select-none
          ${isActive 
            ? 'border-cyan-400 bg-gradient-to-br from-cyan-500/10 to-blue-500/10' 
            : 'border-white/20 bg-white/5'
          }
          ${isPressed 
            ? 'border-green-400 bg-gradient-to-br from-green-500/20 to-emerald-400/20 shadow-2xl' 
            : ''
          }
          hover:scale-[1.02] active:scale-[0.98]
        `}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
      >
        {/* Animated background */}
        {isPressed && (
          <div className="absolute inset-0 bg-gradient-to-t from-green-500/20 to-transparent rounded-2xl animate-pulse"></div>
        )}
        
        {/* Content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-center space-y-3">
            <div className={`transition-all duration-300 ${
              isPressed ? 'scale-110' : 'scale-100'
            }`}>
              <Hand className={`w-16 h-16 mx-auto transition-colors duration-300 ${
                isPressed ? 'text-green-400' : 'text-white/60'
              }`} />
            </div>
            
            <div className="space-y-2">
              <div className={`font-medium transition-colors duration-300 ${
                isPressed ? 'text-green-400' : 'text-white'
              }`}>
                {isActive 
                  ? (isPressed ? 'Compressing...' : 'Touch and press firmly')
                  : 'Start session to begin'
                }
              </div>
              
              {isPressed && (
                <div className="space-y-1">
                  <div className="text-sm text-purple-200">
                    Pressure: {pressureIntensity.toFixed(0)}%
                  </div>
                  <div className="w-24 h-2 bg-white/20 rounded-full mx-auto overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-yellow-400 to-red-400 transition-all duration-300"
                      style={{ width: `${pressureIntensity}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Compression depth visualization */}
        {isPressed && (
          <div 
            className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-cyan-400/30 to-transparent rounded-b-2xl transition-all duration-300"
            style={{ 
              height: `${depthPercentage}%`,
            }}
          />
        )}

        {/* Ripple effect on press */}
        {isPressed && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-32 h-32 border-2 border-green-400/50 rounded-full animate-ping"></div>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="mt-4 text-center">
        <div className="text-xs text-purple-300 flex items-center justify-center gap-1">
          <Zap className="w-3 h-3" />
          Use firm, steady pressure. Pressure sensitivity may vary on different devices.
        </div>
      </div>
    </div>
  );
}