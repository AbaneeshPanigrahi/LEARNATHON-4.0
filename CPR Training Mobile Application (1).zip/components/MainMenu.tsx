import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Heart, User, Baby, Trophy, BarChart3, Play, Sparkles, Zap } from 'lucide-react';

interface MainMenuProps {
  onStartTraining: (scenario: 'adult' | 'child' | 'infant') => void;
  onViewHistory: () => void;
  onViewAchievements: () => void;
}

export function MainMenu({ onStartTraining, onViewHistory, onViewAchievements }: MainMenuProps) {
  const scenarios = [
    {
      id: 'adult' as const,
      title: 'Adult CPR',
      description: 'Standard adult CPR training',
      icon: User,
      difficulty: 'Beginner',
      compressionRate: '100-120/min',
      depth: '5-6 cm',
      gradient: 'from-blue-500 to-cyan-400'
    },
    {
      id: 'child' as const,
      title: 'Child CPR',
      description: 'CPR for children (1-8 years)',
      icon: Heart,
      difficulty: 'Intermediate',
      compressionRate: '100-120/min',
      depth: '4-5 cm',
      gradient: 'from-green-500 to-emerald-400'
    },
    {
      id: 'infant' as const,
      title: 'Infant CPR',
      description: 'CPR for infants (&lt;1 year)',
      icon: Baby,
      difficulty: 'Advanced',
      compressionRate: '100-120/min',
      depth: '4 cm',
      gradient: 'from-purple-500 to-pink-400'
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'Intermediate': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'Advanced': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="relative">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-pink-500 rounded-full blur-lg opacity-60"></div>
          </div>
          <div className="relative flex items-center justify-center gap-3 mb-6">
            <div className="p-3 bg-gradient-to-r from-red-500 to-pink-500 rounded-2xl shadow-lg">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">CPR Trainer</h1>
              <div className="flex items-center gap-2 text-purple-200">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm">AI-Powered Training</span>
              </div>
            </div>
          </div>
        </div>
        <p className="text-purple-100 text-lg">Master life-saving CPR skills with interactive training</p>
      </div>

      {/* Training Scenarios */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <h2 className="text-xl font-semibold text-white">Choose Training Scenario</h2>
          <div className="flex-1 h-px bg-gradient-to-r from-white/20 to-transparent"></div>
        </div>
        
        <div className="space-y-4">
          {scenarios.map((scenario) => {
            const Icon = scenario.icon;
            return (
              <div 
                key={scenario.id} 
                className="group relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl cursor-pointer"
                onClick={() => onStartTraining(scenario.id)}
              >
                {/* Gradient accent */}
                <div className={`absolute inset-0 bg-gradient-to-r ${scenario.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300`}></div>
                
                <div className="relative">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`p-3 bg-gradient-to-r ${scenario.gradient} rounded-xl shadow-lg`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="text-lg font-semibold text-white">{scenario.title}</h3>
                        <Badge className={`text-xs border ${getDifficultyColor(scenario.difficulty)}`}>
                          {scenario.difficulty}
                        </Badge>
                      </div>
                      <p className="text-purple-200 text-sm">{scenario.description}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div className="space-y-1">
                      <span className="text-purple-300">Compression Rate</span>
                      <div className="text-white font-medium">{scenario.compressionRate}</div>
                    </div>
                    <div className="space-y-1">
                      <span className="text-purple-300">Target Depth</span>
                      <div className="text-white font-medium">{scenario.depth}</div>
                    </div>
                  </div>
                  
                  <Button 
                    className={`w-full bg-gradient-to-r ${scenario.gradient} hover:opacity-90 text-white border-0 rounded-xl h-12 font-medium shadow-lg transition-all duration-300 group-hover:shadow-xl`}
                    size="lg"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start Training
                    <Zap className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-semibold text-white">Quick Actions</h3>
          <div className="flex-1 h-px bg-gradient-to-r from-white/20 to-transparent"></div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <Button 
            onClick={onViewHistory}
            className="h-16 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-xl backdrop-blur-sm transition-all duration-300 hover:scale-105 group"
          >
            <div className="flex flex-col items-center gap-2">
              <div className="p-2 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-lg group-hover:scale-110 transition-transform">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-medium">Performance</span>
            </div>
          </Button>
          
          <Button 
            onClick={onViewAchievements}
            className="h-16 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-xl backdrop-blur-sm transition-all duration-300 hover:scale-105 group"
          >
            <div className="flex flex-col items-center gap-2">
              <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-400 rounded-lg group-hover:scale-110 transition-transform">
                <Trophy className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-medium">Achievements</span>
            </div>
          </Button>
        </div>
      </div>

      {/* Stats Preview */}
      <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-4">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-white">5</div>
            <div className="text-xs text-purple-300">Sessions</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-400">85</div>
            <div className="text-xs text-purple-300">Best Score</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-yellow-400">12</div>
            <div className="text-xs text-purple-300">Achievements</div>
          </div>
        </div>
      </div>
    </div>
  );
}