import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  ArrowLeft, 
  Trophy, 
  Star,
  Target,
  Clock,
  Zap,
  Heart,
  Award,
  Lock,
  CheckCircle
} from 'lucide-react';

interface AchievementSystemProps {
  onBack: () => void;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: 'accuracy' | 'endurance' | 'consistency' | 'mastery';
  requirement: string;
  points: number;
  unlocked: boolean;
  progress: number; // 0-100
  unlockedDate?: string;
}

interface PlayerStats {
  level: number;
  totalPoints: number;
  nextLevelPoints: number;
  totalSessions: number;
  perfectSessions: number;
  longestSession: number;
  highestScore: number;
}

export function AchievementSystem({ onBack }: AchievementSystemProps) {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [playerStats, setPlayerStats] = useState<PlayerStats>({
    level: 1,
    totalPoints: 0,
    nextLevelPoints: 100,
    totalSessions: 0,
    perfectSessions: 0,
    longestSession: 0,
    highestScore: 0
  });
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    // Mock achievements data
    const mockAchievements: Achievement[] = [
      {
        id: 'first_steps',
        title: 'First Steps',
        description: 'Complete your first CPR training session',
        icon: <Heart className="w-6 h-6" />,
        category: 'mastery',
        requirement: 'Complete 1 training session',
        points: 10,
        unlocked: true,
        progress: 100,
        unlockedDate: '2025-01-20'
      },
      {
        id: 'accuracy_expert',
        title: 'Accuracy Expert',
        description: 'Achieve 90% compression accuracy',
        icon: <Target className="w-6 h-6" />,
        category: 'accuracy',
        requirement: '90% accuracy in a session',
        points: 25,
        unlocked: true,
        progress: 100,
        unlockedDate: '2025-01-22'
      },
      {
        id: 'perfect_score',
        title: 'Perfect Score',
        description: 'Score 100 points in a training session',
        icon: <Star className="w-6 h-6" />,
        category: 'mastery',
        requirement: 'Score 100/100 points',
        points: 50,
        unlocked: false,
        progress: 85
      },
      {
        id: 'endurance_warrior',
        title: 'Endurance Warrior',
        description: 'Complete a 5-minute training session',
        icon: <Clock className="w-6 h-6" />,
        category: 'endurance',
        requirement: 'Train for 5 minutes',
        points: 30,
        unlocked: false,
        progress: 60
      },
      {
        id: 'consistency_king',
        title: 'Consistency King',
        description: 'Train for 7 consecutive days',
        icon: <Zap className="w-6 h-6" />,
        category: 'consistency',
        requirement: '7 day training streak',
        points: 40,
        unlocked: false,
        progress: 20
      },
      {
        id: 'scenario_master',
        title: 'Scenario Master',
        description: 'Complete all three CPR scenarios',
        icon: <Award className="w-6 h-6" />,
        category: 'mastery',
        requirement: 'Complete Adult, Child & Infant CPR',
        points: 75,
        unlocked: false,
        progress: 67
      },
      {
        id: 'speed_demon',
        title: 'Speed Demon',
        description: 'Maintain perfect compression rate for 2 minutes',
        icon: <Zap className="w-6 h-6" />,
        category: 'accuracy',
        requirement: 'Perfect rate for 2 minutes',
        points: 35,
        unlocked: false,
        progress: 40
      },
      {
        id: 'dedication',
        title: 'Dedicated Trainer',
        description: 'Complete 50 training sessions',
        icon: <Trophy className="w-6 h-6" />,
        category: 'endurance',
        requirement: '50 completed sessions',
        points: 100,
        unlocked: false,
        progress: 10
      }
    ];

    setAchievements(mockAchievements);

    // Calculate player stats
    const unlockedAchievements = mockAchievements.filter(a => a.unlocked);
    const totalPoints = unlockedAchievements.reduce((sum, a) => sum + a.points, 0);
    const level = Math.floor(totalPoints / 100) + 1;
    const nextLevelPoints = level * 100;

    setPlayerStats({
      level,
      totalPoints,
      nextLevelPoints,
      totalSessions: 5,
      perfectSessions: 1,
      longestSession: 300, // 5 minutes
      highestScore: 85
    });
  }, []);

  const categories = [
    { id: 'all', name: 'All', icon: Trophy },
    { id: 'accuracy', name: 'Accuracy', icon: Target },
    { id: 'endurance', name: 'Endurance', icon: Clock },
    { id: 'consistency', name: 'Consistency', icon: Zap },
    { id: 'mastery', name: 'Mastery', icon: Award }
  ];

  const filteredAchievements = selectedCategory === 'all' 
    ? achievements 
    : achievements.filter(a => a.category === selectedCategory);

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const progressToNextLevel = ((playerStats.totalPoints % 100) / 100) * 100;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </div>

      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-gray-800">Achievements</h1>
        <p className="text-gray-600">Unlock rewards as you master CPR skills</p>
      </div>

      {/* Player Level & Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Your Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-600">Level {playerStats.level}</div>
              <div className="text-sm text-gray-600">{playerStats.totalPoints} / {playerStats.nextLevelPoints} points</div>
            </div>
            <Badge variant="outline" className="text-lg px-3 py-1">
              {unlockedCount}/{achievements.length} Unlocked
            </Badge>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span>Progress to Level {playerStats.level + 1}</span>
              <span>{Math.round(progressToNextLevel)}%</span>
            </div>
            <Progress value={progressToNextLevel} className="h-3" />
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center p-2 bg-blue-50 rounded">
              <div className="font-semibold text-blue-600">{playerStats.totalSessions}</div>
              <div className="text-gray-600">Sessions</div>
            </div>
            <div className="text-center p-2 bg-green-50 rounded">
              <div className="font-semibold text-green-600">{playerStats.highestScore}</div>
              <div className="text-gray-600">Best Score</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map(category => {
          const Icon = category.icon;
          return (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="flex items-center gap-2 whitespace-nowrap"
            >
              <Icon className="w-4 h-4" />
              {category.name}
            </Button>
          );
        })}
      </div>

      {/* Achievements List */}
      <div className="space-y-3">
        {filteredAchievements.map(achievement => (
          <Card 
            key={achievement.id} 
            className={`transition-all ${
              achievement.unlocked 
                ? 'border-green-200 bg-green-50' 
                : 'border-gray-200'
            }`}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-lg ${
                  achievement.unlocked 
                    ? 'bg-green-100 text-green-600' 
                    : 'bg-gray-100 text-gray-400'
                }`}>
                  {achievement.unlocked ? achievement.icon : <Lock className="w-6 h-6" />}
                </div>
                
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className={`font-semibold ${
                      achievement.unlocked ? 'text-gray-900' : 'text-gray-500'
                    }`}>
                      {achievement.title}
                    </h3>
                    <div className="flex items-center gap-2">
                      {achievement.unlocked && (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      )}
                      <Badge variant={achievement.unlocked ? 'default' : 'secondary'}>
                        +{achievement.points} pts
                      </Badge>
                    </div>
                  </div>
                  
                  <p className={`text-sm ${
                    achievement.unlocked ? 'text-gray-700' : 'text-gray-500'
                  }`}>
                    {achievement.description}
                  </p>
                  
                  <div className="text-xs text-gray-500">
                    {achievement.requirement}
                  </div>

                  {!achievement.unlocked && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Progress</span>
                        <span>{achievement.progress}%</span>
                      </div>
                      <Progress value={achievement.progress} className="h-1" />
                    </div>
                  )}

                  {achievement.unlocked && achievement.unlockedDate && (
                    <div className="text-xs text-green-600">
                      Unlocked {formatDate(achievement.unlockedDate)}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Next Achievement Hint */}
      <Card className="border-dashed border-2 border-blue-300">
        <CardContent className="p-4 text-center">
          <Trophy className="w-8 h-8 text-blue-400 mx-auto mb-2" />
          <h3 className="font-medium text-blue-600 mb-1">Next Achievement</h3>
          <p className="text-sm text-blue-500">
            You're {100 - (filteredAchievements.find(a => !a.unlocked)?.progress || 0)}% away from unlocking "{filteredAchievements.find(a => !a.unlocked)?.title}"
          </p>
        </CardContent>
      </Card>
    </div>
  );
}