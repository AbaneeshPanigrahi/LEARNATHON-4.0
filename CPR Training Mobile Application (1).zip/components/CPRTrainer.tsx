import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  RotateCcw, 
  Heart,
  Activity,
  Timer,
  Target,
  Zap
} from 'lucide-react';
import { CompressionMonitor } from './CompressionMonitor';
import { FeedbackDisplay } from './FeedbackDisplay';
import { VirtualPatient } from './VirtualPatient';

interface CPRTrainerProps {
  scenario: 'adult' | 'child' | 'infant';
  onExit: () => void;
}

interface CompressionData {
  depth: number;
  rate: number;
  timestamp: number;
}

interface SessionStats {
  totalCompressions: number;
  averageDepth: number;
  averageRate: number;
  correctCompressions: number;
  sessionDuration: number;
  score: number;
}

export function CPRTrainer({ scenario, onExit }: CPRTrainerProps) {
  const [isActive, setIsActive] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [compressions, setCompressions] = useState<CompressionData[]>([]);
  const [currentFeedback, setCurrentFeedback] = useState<string>('');
  const [sessionStats, setSessionStats] = useState<SessionStats>({
    totalCompressions: 0,
    averageDepth: 0,
    averageRate: 0,
    correctCompressions: 0,
    sessionDuration: 0,
    score: 0
  });

  const sessionStartRef = useRef<number>(0);
  const timerRef = useRef<NodeJS.Timeout>();

  const scenarioConfig = {
    adult: { targetDepth: [5, 6], targetRate: [100, 120], name: 'Adult', gradient: 'from-blue-500 to-cyan-400' },
    child: { targetDepth: [4, 5], targetRate: [100, 120], name: 'Child', gradient: 'from-green-500 to-emerald-400' },
    infant: { targetDepth: [3, 4], targetRate: [100, 120], name: 'Infant', gradient: 'from-purple-500 to-pink-400' }
  }[scenario];

  const startSession = () => {
    setIsActive(true);
    sessionStartRef.current = Date.now();
    setSessionTime(0);
    setCompressions([]);
    setSessionStats({
      totalCompressions: 0,
      averageDepth: 0,
      averageRate: 0,
      correctCompressions: 0,
      sessionDuration: 0,
      score: 0
    });
    
    timerRef.current = setInterval(() => {
      setSessionTime(prev => prev + 1);
    }, 1000);
  };

  const pauseSession = () => {
    setIsActive(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const resetSession = () => {
    setIsActive(false);
    setSessionTime(0);
    setCompressions([]);
    setCurrentFeedback('');
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const handleCompression = useCallback((depth: number) => {
    if (!isActive) return;

    const now = Date.now();
    const newCompression: CompressionData = {
      depth,
      rate: 0,
      timestamp: now
    };

    setCompressions(prev => {
      const updated = [...prev, newCompression];
      
      if (updated.length >= 2) {
        const recentCompressions = updated.slice(-6);
        const timeSpan = (recentCompressions[recentCompressions.length - 1].timestamp - recentCompressions[0].timestamp) / 1000;
        const rate = (recentCompressions.length - 1) / timeSpan * 60;
        newCompression.rate = rate;
      }

      return updated;
    });

    const depthFeedback = 
      depth < scenarioConfig.targetDepth[0] ? 'Push deeper!' :
      depth > scenarioConfig.targetDepth[1] ? 'Too deep!' :
      'Good depth!';
    
    setCurrentFeedback(depthFeedback);
  }, [isActive, scenarioConfig.targetDepth]);

  const calculateStats = useCallback(() => {
    if (compressions.length === 0) return;

    const totalCompressions = compressions.length;
    const averageDepth = compressions.reduce((sum, c) => sum + c.depth, 0) / totalCompressions;
    const recentRates = compressions.filter(c => c.rate > 0).map(c => c.rate);
    const averageRate = recentRates.length > 0 ? recentRates.reduce((sum, r) => sum + r, 0) / recentRates.length : 0;
    
    const correctCompressions = compressions.filter(c => 
      c.depth >= scenarioConfig.targetDepth[0] && 
      c.depth <= scenarioConfig.targetDepth[1]
    ).length;

    const depthScore = (correctCompressions / totalCompressions) * 50;
    const rateScore = averageRate >= scenarioConfig.targetRate[0] && averageRate <= scenarioConfig.targetRate[1] ? 50 : 0;
    const score = Math.round(depthScore + rateScore);

    setSessionStats({
      totalCompressions,
      averageDepth: Math.round(averageDepth * 10) / 10,
      averageRate: Math.round(averageRate),
      correctCompressions,
      sessionDuration: sessionTime,
      score
    });
  }, [compressions, sessionTime, scenarioConfig]);

  useEffect(() => {
    calculateStats();
  }, [compressions, calculateStats]);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button 
          variant="ghost" 
          onClick={onExit} 
          className="text-white hover:bg-white/10 rounded-xl"
          size="sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Badge className={`bg-gradient-to-r ${scenarioConfig.gradient} text-white border-0 px-4 py-1 rounded-full`}>
          {scenarioConfig.name} CPR
        </Badge>
      </div>

      {/* Virtual Patient */}
      <VirtualPatient scenario={scenario} isActive={isActive} compressions={compressions} />

      {/* Session Control */}
      <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-400 rounded-lg">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-white">Training Session</h3>
        </div>

        {/* Stats Display */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-1">{formatTime(sessionTime)}</div>
            <div className="text-purple-300 text-sm flex items-center justify-center gap-1">
              <Timer className="w-4 h-4" />
              Duration
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400 mb-1">{sessionStats.totalCompressions}</div>
            <div className="text-purple-300 text-sm flex items-center justify-center gap-1">
              <Heart className="w-4 h-4" />
              Compressions
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-3 mb-6">
          <div className="flex justify-between text-sm">
            <span className="text-purple-200 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Session Progress
            </span>
            <span className="text-white font-medium">{sessionStats.score}/100</span>
          </div>
          <div className="relative">
            <Progress value={sessionStats.score} className="h-3 bg-white/10 rounded-full overflow-hidden" />
            <div 
              className="absolute top-0 left-0 h-3 bg-gradient-to-r from-green-500 to-emerald-400 rounded-full transition-all duration-300"
              style={{ width: `${sessionStats.score}%` }}
            ></div>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="grid grid-cols-3 gap-3">
          <Button 
            onClick={startSession} 
            disabled={isActive}
            className={`h-12 rounded-xl transition-all duration-300 ${
              isActive 
                ? 'bg-white/10 text-white/50 cursor-not-allowed' 
                : 'bg-gradient-to-r from-green-500 to-emerald-400 hover:opacity-90 text-white border-0 shadow-lg'
            }`}
          >
            <Play className="w-4 h-4 mr-2" />
            Start
          </Button>
          <Button 
            onClick={pauseSession} 
            disabled={!isActive}
            className="h-12 bg-white/5 border border-white/20 hover:bg-white/10 text-white rounded-xl transition-all duration-300"
          >
            <Pause className="w-4 h-4 mr-2" />
            Pause
          </Button>
          <Button 
            onClick={resetSession}
            className="h-12 bg-white/5 border border-white/20 hover:bg-white/10 text-white rounded-xl transition-all duration-300"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>
      </div>

      {/* Compression Monitor */}
      <CompressionMonitor
        isActive={isActive}
        onCompression={handleCompression}
        targetDepth={scenarioConfig.targetDepth}
      />

      {/* Feedback Display */}
      <FeedbackDisplay
        feedback={currentFeedback}
        currentDepth={compressions[compressions.length - 1]?.depth || 0}
        currentRate={compressions[compressions.length - 1]?.rate || 0}
        targetDepth={scenarioConfig.targetDepth}
        targetRate={scenarioConfig.targetRate}
      />

      {/* Performance Metrics */}
      <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-lg">
            <Target className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-white">Performance Metrics</h3>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="text-purple-300 text-sm">Average Depth</div>
            <div className="text-white font-semibold text-lg">{sessionStats.averageDepth} cm</div>
          </div>
          <div className="space-y-1">
            <div className="text-purple-300 text-sm">Average Rate</div>
            <div className="text-white font-semibold text-lg">{sessionStats.averageRate}/min</div>
          </div>
          <div className="space-y-1">
            <div className="text-purple-300 text-sm">Correct Compressions</div>
            <div className="text-white font-semibold text-lg">{sessionStats.correctCompressions}/{sessionStats.totalCompressions}</div>
          </div>
          <div className="space-y-1">
            <div className="text-purple-300 text-sm">Accuracy</div>
            <div className="text-green-400 font-semibold text-lg">
              {sessionStats.totalCompressions > 0 
                ? Math.round((sessionStats.correctCompressions / sessionStats.totalCompressions) * 100)
                : 0}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}