import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  User, 
  Heart, 
  Baby, 
  Activity,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface VirtualPatientProps {
  scenario: 'adult' | 'child' | 'infant';
  isActive: boolean;
  compressions: Array<{ depth: number; rate: number; timestamp: number }>;
}

interface PatientState {
  consciousness: 'unconscious' | 'responsive';
  pulse: 'none' | 'weak' | 'normal';
  breathing: 'none' | 'shallow' | 'normal';
  circulation: number; // 0-100%
  oxygenLevel: number; // 0-100%
}

export function VirtualPatient({ scenario, isActive, compressions }: VirtualPatientProps) {
  const [patientState, setPatientState] = useState<PatientState>({
    consciousness: 'unconscious',
    pulse: 'none',
    breathing: 'none',
    circulation: 10,
    oxygenLevel: 70
  });

  const [compressionCount, setCompressionCount] = useState(0);

  const patientInfo = useMemo(() => ({
    adult: {
      name: 'Alex Johnson',
      age: 45,
      icon: User,
      scenario: 'Sudden cardiac arrest at workplace',
      weight: '70 kg',
      targetDepth: '5-6 cm'
    },
    child: {
      name: 'Sam Wilson',
      age: 6,
      icon: User,
      scenario: 'Drowning incident at pool',
      weight: '20 kg',
      targetDepth: '4-5 cm'
    },
    infant: {
      name: 'Baby Taylor',
      age: '8 months',
      icon: Baby,
      scenario: 'Choking and cardiac arrest',
      weight: '8 kg',
      targetDepth: '4 cm'
    }
  }[scenario]), [scenario]);

  // Memoize recent compressions to prevent unnecessary recalculations
  const recentCompressions = useMemo(() => {
    return compressions.slice(-10); // Last 10 compressions
  }, [compressions]);

  // Memoize effective compressions calculation
  const effectiveCompressions = useMemo(() => {
    const minDepth = scenario === 'infant' ? 3 : scenario === 'child' ? 4 : 5;
    return recentCompressions.filter(c => c.depth >= minDepth);
  }, [recentCompressions, scenario]);

  // Memoize effectiveness calculation
  const effectiveness = useMemo(() => {
    return effectiveCompressions.length / Math.max(recentCompressions.length, 1);
  }, [effectiveCompressions.length, recentCompressions.length]);

  const updatePatientState = useCallback((effectiveness: number, recentCompressionsLength: number) => {
    setPatientState(prev => {
      let newCirculation = prev.circulation;
      let newOxygenLevel = prev.oxygenLevel;
      let newPulse = prev.pulse;
      let newBreathing = prev.breathing;
      let newConsciousness = prev.consciousness;

      if (effectiveness > 0.7 && recentCompressionsLength >= 5) {
        // Good CPR
        newCirculation = Math.min(prev.circulation + 2, 85);
        newOxygenLevel = Math.min(prev.oxygenLevel + 1.5, 95);
        
        if (newCirculation > 40) newPulse = 'weak';
        if (newCirculation > 60) newPulse = 'normal';
        if (newOxygenLevel > 85) newBreathing = 'shallow';
        if (newOxygenLevel > 92) newBreathing = 'normal';
        if (newCirculation > 70 && newOxygenLevel > 90) newConsciousness = 'responsive';
      } else if (effectiveness > 0.3) {
        // Moderate CPR
        newCirculation = Math.min(prev.circulation + 0.5, 50);
        newOxygenLevel = Math.min(prev.oxygenLevel + 0.3, 80);
      } else {
        // Poor or no CPR
        newCirculation = Math.max(prev.circulation - 1, 5);
        newOxygenLevel = Math.max(prev.oxygenLevel - 0.5, 60);
        newPulse = 'none';
        newBreathing = 'none';
        newConsciousness = 'unconscious';
      }

      return {
        circulation: newCirculation,
        oxygenLevel: newOxygenLevel,
        pulse: newPulse,
        breathing: newBreathing,
        consciousness: newConsciousness
      };
    });
  }, []);

  // Reset patient state when not active
  useEffect(() => {
    if (!isActive) {
      setPatientState({
        consciousness: 'unconscious',
        pulse: 'none',
        breathing: 'none',
        circulation: 10,
        oxygenLevel: 70
      });
      setCompressionCount(0);
    }
  }, [isActive]);

  // Update patient state based on CPR effectiveness
  useEffect(() => {
    if (isActive && recentCompressions.length > 0) {
      updatePatientState(effectiveness, recentCompressions.length);
      setCompressionCount(compressions.length);
    }
  }, [isActive, effectiveness, recentCompressions.length, compressions.length, updatePatientState]);

  const getStatusColor = (value: number, thresholds: [number, number]) => {
    if (value >= thresholds[1]) return 'text-green-600';
    if (value >= thresholds[0]) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'normal': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'weak':
      case 'shallow': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      default: return <AlertTriangle className="w-4 h-4 text-red-600" />;
    }
  };

  const PatientIcon = patientInfo.icon;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-red-500" />
          Virtual Patient
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Patient Info */}
        <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
          <PatientIcon className="w-12 h-12 text-blue-600" />
          <div>
            <div className="font-semibold">{patientInfo.name}</div>
            <div className="text-sm text-gray-600">Age: {patientInfo.age}</div>
            <div className="text-sm text-gray-600">Weight: {patientInfo.weight}</div>
          </div>
          <Badge variant="outline" className="ml-auto">
            {scenario.charAt(0).toUpperCase() + scenario.slice(1)}
          </Badge>
        </div>

        {/* Scenario Description */}
        <div className="p-3 bg-yellow-50 rounded-lg">
          <div className="text-sm font-medium text-yellow-800 mb-1">Emergency Scenario</div>
          <div className="text-sm text-yellow-700">{patientInfo.scenario}</div>
          <div className="text-xs text-yellow-600 mt-1">
            Target compression depth: {patientInfo.targetDepth}
          </div>
        </div>

        {/* Patient Vital Signs */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Consciousness</span>
            <div className="flex items-center gap-2">
              {getStatusIcon(patientState.consciousness)}
              <Badge variant={patientState.consciousness === 'responsive' ? 'default' : 'secondary'}>
                {patientState.consciousness}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Pulse</span>
            <div className="flex items-center gap-2">
              {getStatusIcon(patientState.pulse)}
              <Badge variant={patientState.pulse === 'normal' ? 'default' : 'secondary'}>
                {patientState.pulse}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Breathing</span>
            <div className="flex items-center gap-2">
              {getStatusIcon(patientState.breathing)}
              <Badge variant={patientState.breathing === 'normal' ? 'default' : 'secondary'}>
                {patientState.breathing}
              </Badge>
            </div>
          </div>

          {/* Circulation */}
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span>Circulation</span>
              <span className={getStatusColor(patientState.circulation, [40, 70])}>
                {patientState.circulation}%
              </span>
            </div>
            <Progress value={patientState.circulation} className="h-2" />
          </div>

          {/* Oxygen Level */}
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span>Oxygen Saturation</span>
              <span className={getStatusColor(patientState.oxygenLevel, [85, 95])}>
                {patientState.oxygenLevel}%
              </span>
            </div>
            <Progress value={patientState.oxygenLevel} className="h-2" />
          </div>
        </div>

        {/* CPR Progress */}
        <div className="p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4" />
            <span className="text-sm font-medium">CPR Progress</span>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-gray-500">Compressions Given</div>
              <div className="font-semibold text-blue-600">{compressionCount}</div>
            </div>
            <div>
              <div className="text-gray-500">Patient Response</div>
              <div className={`font-semibold ${
                patientState.circulation > 50 ? 'text-green-600' : 
                patientState.circulation > 25 ? 'text-yellow-600' : 'text-red-600'
              }`}>
                {patientState.circulation > 50 ? 'Improving' : 
                 patientState.circulation > 25 ? 'Stable' : 'Critical'}
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Status */}
        {isActive && (
          <div className="text-center text-sm text-gray-600">
            {patientState.consciousness === 'responsive' ? (
              <div className="text-green-600 font-medium">
                ✅ Patient is responding! Continue CPR until EMS arrives.
              </div>
            ) : patientState.circulation > 40 ? (
              <div className="text-blue-600">
                🔄 Patient showing signs of improvement. Keep going!
              </div>
            ) : (
              <div className="text-red-600">
                ⚠️ Patient in critical condition. Maintain effective CPR!
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}