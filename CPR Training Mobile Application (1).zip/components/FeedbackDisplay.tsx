import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Badge } from './ui/badge';
import { 
  MessageSquare, 
  CheckCircle, 
  AlertTriangle, 
  TrendingUp,
  TrendingDown,
  Minus,
  Volume2,
  VolumeX,
  Sparkles
} from 'lucide-react';

interface FeedbackDisplayProps {
  feedback: string;
  currentDepth: number;
  currentRate: number;
  targetDepth: [number, number];
  targetRate: [number, number];
}

interface FeedbackMessage {
  type: 'success' | 'warning' | 'error' | 'info';
  message: string;
  icon: React.ReactNode;
}

export function FeedbackDisplay({ 
  feedback, 
  currentDepth, 
  currentRate, 
  targetDepth, 
  targetRate 
}: FeedbackDisplayProps) {
  const [messages, setMessages] = useState<FeedbackMessage[]>([]);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const lastFeedbackRef = useRef<string>('');

  // Stabilize target values to prevent dependency changes
  const stableTargetDepth = useMemo(() => targetDepth, [targetDepth[0], targetDepth[1]]);
  const stableTargetRate = useMemo(() => targetRate, [targetRate[0], targetRate[1]]);

  const getFeedbackType = useCallback((depth: number, rate: number): FeedbackMessage => {
    let depthStatus: 'good' | 'shallow' | 'deep' = 'good';
    if (depth < stableTargetDepth[0]) depthStatus = 'shallow';
    else if (depth > stableTargetDepth[1]) depthStatus = 'deep';

    let rateStatus: 'good' | 'slow' | 'fast' = 'good';
    if (rate > 0) {
      if (rate < stableTargetRate[0]) rateStatus = 'slow';
      else if (rate > stableTargetRate[1]) rateStatus = 'fast';
    }

    if (depthStatus === 'good' && rateStatus === 'good') {
      return {
        type: 'success',
        message: 'Excellent! Perfect depth and rate',
        icon: <CheckCircle className="w-4 h-4" />
      };
    }

    if (depthStatus === 'shallow') {
      return {
        type: 'error',
        message: 'Push deeper! Increase compression depth',
        icon: <TrendingDown className="w-4 h-4" />
      };
    }

    if (depthStatus === 'deep') {
      return {
        type: 'warning',
        message: 'Too deep! Reduce compression force',
        icon: <TrendingUp className="w-4 h-4" />
      };
    }

    if (rateStatus === 'slow') {
      return {
        type: 'warning',
        message: 'Compress faster! Increase rate',
        icon: <TrendingUp className="w-4 h-4" />
      };
    }

    if (rateStatus === 'fast') {
      return {
        type: 'warning',
        message: 'Slow down! Decrease compression rate',
        icon: <TrendingDown className="w-4 h-4" />
      };
    }

    return {
      type: 'info',
      message: 'Keep going! Maintain steady compressions',
      icon: <Minus className="w-4 h-4" />
    };
  }, [stableTargetDepth, stableTargetRate]);

  // Use useEffect to update messages only when meaningful changes occur
  useEffect(() => {
    if (currentDepth > 0 || currentRate > 0) {
      const newFeedback = getFeedbackType(currentDepth, currentRate);
      const feedbackKey = `${newFeedback.message}-${currentDepth.toFixed(1)}-${currentRate.toFixed(0)}`;
      
      // Only update if the feedback has actually changed
      if (lastFeedbackRef.current !== feedbackKey) {
        lastFeedbackRef.current = feedbackKey;
        
        setMessages(prev => {
          const lastMessage = prev[prev.length - 1];
          if (!lastMessage || lastMessage.message !== newFeedback.message) {
            return [...prev, newFeedback].slice(-5); // Keep last 5 messages
          }
          return prev;
        });

        // Audio feedback
        if (audioEnabled && newFeedback.type === 'success') {
          console.log('🔊 Audio: Good compression!');
        }
      }
    }
  }, [currentDepth, currentRate, getFeedbackType, audioEnabled]);

  const getStatusColor = (value: number, range: [number, number]) => {
    if (value >= range[0] && value <= range[1]) return 'text-green-400';
    if (value < range[0] || value > range[1]) return 'text-red-400';
    return 'text-white';
  };

  const getAlertColors = (type: string) => {
    switch (type) {
      case 'success': return 'bg-green-500/20 border-green-500/30 text-green-300';
      case 'warning': return 'bg-yellow-500/20 border-yellow-500/30 text-yellow-300';
      case 'error': return 'bg-red-500/20 border-red-500/30 text-red-300';
      default: return 'bg-blue-500/20 border-blue-500/30 text-blue-300';
    }
  };

  const currentMessage = messages[messages.length - 1];

  return (
    <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-400 rounded-lg">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-white">Real-time Feedback</h3>
        </div>
        
        {/* Audio Toggle */}
        <button
          onClick={() => setAudioEnabled(!audioEnabled)}
          className={`p-2 rounded-lg transition-all duration-300 ${
            audioEnabled 
              ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
              : 'bg-white/5 text-white/60 border border-white/10'
          }`}
        >
          {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>

      {/* Current Status Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-4 text-center">
          <div className="text-purple-300 text-sm mb-2">Current Depth</div>
          <div className={`text-2xl font-bold mb-2 ${getStatusColor(currentDepth, stableTargetDepth)}`}>
            {currentDepth.toFixed(1)} cm
          </div>
          <Badge className={`text-xs ${
            currentDepth >= stableTargetDepth[0] && currentDepth <= stableTargetDepth[1] 
              ? "bg-green-500/20 text-green-300 border-green-500/30" 
              : "bg-white/10 text-white/70 border-white/20"
          }`}>
            Target: {stableTargetDepth[0]}-{stableTargetDepth[1]}cm
          </Badge>
        </div>
        
        <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-4 text-center">
          <div className="text-purple-300 text-sm mb-2">Current Rate</div>
          <div className={`text-2xl font-bold mb-2 ${getStatusColor(currentRate, stableTargetRate)}`}>
            {currentRate > 0 ? Math.round(currentRate) : 0}/min
          </div>
          <Badge className={`text-xs ${
            currentRate >= stableTargetRate[0] && currentRate <= stableTargetRate[1] 
              ? "bg-green-500/20 text-green-300 border-green-500/30" 
              : "bg-white/10 text-white/70 border-white/20"
          }`}>
            Target: {stableTargetRate[0]}-{stableTargetRate[1]}/min
          </Badge>
        </div>
      </div>

      {/* Main Feedback Message */}
      {currentMessage && (
        <div className={`border rounded-xl p-4 mb-6 ${getAlertColors(currentMessage.type)}`}>
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0">
              {currentMessage.icon}
            </div>
            <div className="font-medium flex-1">
              {currentMessage.message}
            </div>
            {currentMessage.type === 'success' && (
              <Sparkles className="w-4 h-4 text-green-400 animate-pulse" />
            )}
          </div>
        </div>
      )}

      {/* CPR Rhythm Guide */}
      <div className="text-center mb-6">
        <div className="text-purple-200 text-sm mb-3">Remember: 🎵 "Stayin' Alive" rhythm</div>
        <div className="flex justify-center space-x-2">
          {[1,2,3,4].map(beat => (
            <div 
              key={beat}
              className="w-3 h-3 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full animate-pulse"
              style={{ animationDelay: `${beat * 0.5}s` }}
            />
          ))}
        </div>
      </div>

      {/* Recent Messages History */}
      {messages.length > 1 && (
        <div className="space-y-3">
          <div className="text-sm text-purple-300 flex items-center gap-2">
            <div className="w-4 h-px bg-gradient-to-r from-purple-400 to-transparent"></div>
            Recent feedback
          </div>
          <div className="space-y-2 max-h-20 overflow-y-auto">
            {messages.slice(-3, -1).map((msg, index) => (
              <div key={index} className="text-xs text-white/60 flex items-center gap-2 p-2 bg-white/5 rounded-lg">
                <div className="text-white/40">
                  {msg.icon}
                </div>
                {msg.message}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}