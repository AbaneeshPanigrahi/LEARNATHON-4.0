import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  ArrowLeft, 
  TrendingUp, 
  Calendar,
  Target,
  Clock,
  BarChart3
} from 'lucide-react';

interface PerformanceHistoryProps {
  onBack: () => void;
}

interface TrainingSession {
  id: string;
  date: string;
  scenario: 'adult' | 'child' | 'infant';
  duration: number; // seconds
  totalCompressions: number;
  averageDepth: number;
  averageRate: number;
  score: number;
  correctCompressions: number;
}

export function PerformanceHistory({ onBack }: PerformanceHistoryProps) {
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'all'>('week');

  // Mock data for demonstration
  useEffect(() => {
    const mockSessions: TrainingSession[] = [
      {
        id: '1',
        date: '2025-01-24',
        scenario: 'adult',
        duration: 180,
        totalCompressions: 45,
        averageDepth: 5.2,
        averageRate: 110,
        score: 85,
        correctCompressions: 38
      },
      {
        id: '2',
        date: '2025-01-23',
        scenario: 'child',
        duration: 150,
        totalCompressions: 38,
        averageDepth: 4.3,
        averageRate: 105,
        score: 78,
        correctCompressions: 30
      },
      {
        id: '3',
        date: '2025-01-22',
        scenario: 'adult',
        duration: 200,
        totalCompressions: 52,
        averageDepth: 4.8,
        averageRate: 95,
        score: 72,
        correctCompressions: 35
      },
      {
        id: '4',
        date: '2025-01-21',
        scenario: 'infant',
        duration: 120,
        totalCompressions: 30,
        averageDepth: 3.8,
        averageRate: 115,
        score: 68,
        correctCompressions: 22
      },
      {
        id: '5',
        date: '2025-01-20',
        scenario: 'adult',
        duration: 170,
        totalCompressions: 42,
        averageDepth: 5.5,
        averageRate: 108,
        score: 82,
        correctCompressions: 36
      }
    ];
    setSessions(mockSessions);
  }, []);

  const filteredSessions = sessions.filter(session => {
    const sessionDate = new Date(session.date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - sessionDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    switch (selectedPeriod) {
      case 'week': return diffDays <= 7;
      case 'month': return diffDays <= 30;
      default: return true;
    }
  });

  const calculateStats = () => {
    if (filteredSessions.length === 0) return null;

    const totalSessions = filteredSessions.length;
    const averageScore = Math.round(
      filteredSessions.reduce((sum, s) => sum + s.score, 0) / totalSessions
    );
    const totalDuration = filteredSessions.reduce((sum, s) => sum + s.duration, 0);
    const totalCompressions = filteredSessions.reduce((sum, s) => sum + s.totalCompressions, 0);
    const averageAccuracy = Math.round(
      filteredSessions.reduce((sum, s) => sum + (s.correctCompressions / s.totalCompressions * 100), 0) / totalSessions
    );

    const improvementTrend = filteredSessions.length >= 2 
      ? filteredSessions[0].score - filteredSessions[filteredSessions.length - 1].score
      : 0;

    return {
      totalSessions,
      averageScore,
      totalDuration,
      totalCompressions,
      averageAccuracy,
      improvementTrend
    };
  };

  const stats = calculateStats();

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: '2-digit'
    });
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadgeVariant = (score: number) => {
    if (score >= 80) return 'default';
    if (score >= 60) return 'secondary';
    return 'destructive';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div className="flex gap-2">
          {(['week', 'month', 'all'] as const).map(period => (
            <Button
              key={period}
              variant={selectedPeriod === period ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedPeriod(period)}
            >
              {period === 'all' ? 'All Time' : `Last ${period}`}
            </Button>
          ))}
        </div>
      </div>

      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-gray-800">Performance History</h1>
        <p className="text-gray-600">Track your CPR training progress over time</p>
      </div>

      {stats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Summary Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{stats.totalSessions}</div>
                <div className="text-sm text-gray-600">Training Sessions</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className={`text-2xl font-bold ${getScoreColor(stats.averageScore)}`}>
                  {stats.averageScore}
                </div>
                <div className="text-sm text-gray-600">Average Score</div>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{stats.totalCompressions}</div>
                <div className="text-sm text-gray-600">Total Compressions</div>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">{stats.averageAccuracy}%</div>
                <div className="text-sm text-gray-600">Average Accuracy</div>
              </div>
            </div>
            
            {stats.improvementTrend !== 0 && (
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className={`w-4 h-4 ${stats.improvementTrend > 0 ? 'text-green-600' : 'text-red-600'}`} />
                  <span>
                    {stats.improvementTrend > 0 ? 'Improving' : 'Declining'} by {Math.abs(stats.improvementTrend)} points
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        <h2 className="font-semibold text-gray-800">Recent Sessions</h2>
        {filteredSessions.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-medium text-gray-600 mb-2">No training sessions found</h3>
              <p className="text-sm text-gray-500">Start a training session to see your performance history</p>
            </CardContent>
          </Card>
        ) : (
          filteredSessions.map(session => (
            <Card key={session.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      {session.scenario.charAt(0).toUpperCase() + session.scenario.slice(1)} CPR
                    </Badge>
                    <span className="text-sm text-gray-500">{formatDate(session.date)}</span>
                  </div>
                  <Badge variant={getScoreBadgeVariant(session.score)}>
                    {session.score}/100
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span>Duration: {formatDuration(session.duration)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-gray-400" />
                      <span>Compressions: {session.totalCompressions}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <span className="text-gray-500">Avg Depth:</span>
                      <span className="ml-2 font-medium">{session.averageDepth} cm</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Avg Rate:</span>
                      <span className="ml-2 font-medium">{session.averageRate}/min</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Accuracy</span>
                    <span>{Math.round((session.correctCompressions / session.totalCompressions) * 100)}%</span>
                  </div>
                  <Progress 
                    value={(session.correctCompressions / session.totalCompressions) * 100} 
                    className="h-2"
                  />
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}