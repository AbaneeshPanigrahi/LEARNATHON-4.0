import React, { useState } from 'react';
import { CPRTrainer } from './components/CPRTrainer';
import { MainMenu } from './components/MainMenu';
import { PerformanceHistory } from './components/PerformanceHistory';
import { AchievementSystem } from './components/AchievementSystem';

export default function App() {
  const [currentView, setCurrentView] = useState<'menu' | 'training' | 'history' | 'achievements'>('menu');
  const [selectedScenario, setSelectedScenario] = useState<'adult' | 'child' | 'infant'>('adult');

  const startTraining = (scenario: 'adult' | 'child' | 'infant') => {
    setSelectedScenario(scenario);
    setCurrentView('training');
  };

  const goToMenu = () => {
    setCurrentView('menu');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-10 left-10 w-72 h-72 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-gradient-to-r from-yellow-400 to-red-400 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
      </div>
      
      {/* Main content */}
      <div className="relative z-10 min-h-screen p-6">
        <div className="max-w-md mx-auto">
          {/* Glassmorphism container */}
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-2xl overflow-hidden min-h-[90vh]">
            {currentView === 'menu' && (
              <MainMenu
                onStartTraining={startTraining}
                onViewHistory={() => setCurrentView('history')}
                onViewAchievements={() => setCurrentView('achievements')}
              />
            )}
            {currentView === 'training' && (
              <CPRTrainer
                scenario={selectedScenario}
                onExit={goToMenu}
              />
            )}
            {currentView === 'history' && (
              <PerformanceHistory onBack={goToMenu} />
            )}
            {currentView === 'achievements' && (
              <AchievementSystem onBack={goToMenu} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}